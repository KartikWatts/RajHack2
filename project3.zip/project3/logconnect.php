<?php
@session_start();
$servername = "localhost";
$username = "root";
$pass = "";
$dbname = "rajhack";

$log = 1;
// Create connection
$conn = new mysqli($servername, $username, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

                $user= $_POST['user'];
                $password= $_POST['password'];

$sql= "SELECT * FROM user WHERE user='$user' and password='$password'";
    $result= mysqli_query($conn,$sql);
    while(@$row= mysqli_fetch_array($result, MYSQLI_ASSOC))
    {
        $email=$row["email"];
        $contact=$row["contact"];
        $address=$row["address"];
        $bg=$row["bloodbank"];
        $name=$row["name"];
    

            // Set session variables
            $_SESSION['name'] = $name;
            $_SESSION["user"] = $user;
            $_SESSION["password"] = $password;
            $_SESSION["bg"]= $bg;
            $_SESSION["contact"] = $contact;
            $_SESSION["email"] = $email;
            $_SESSION["address"] = $address;

            $name = $_SESSION['name'];
            $user = $_SESSION['user'];
            $password = $_SESSION['password'];
    }
    $log=1;
    $_SESSION['log'] = $log;
header('Location: index.php');
?>