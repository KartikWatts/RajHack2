<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>The Bank of Life</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--W3.CSS -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/creative.min.css" rel="stylesheet">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


  </head>
<body>
<!-- Navigation -->
    <!--<nav class="navbar navbar-default">
      <a class="navbar-brand page-top" href="#">Bank of Life</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.html">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="locate.html">Locate Banks</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#portfolio">Search Blood</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#myModal" href="#">Login</a>
          </li>
        </ul>
      </div>
    </nav>
	-->
	<div class="w3-bar w3-blue w3-top " style="height:50px; ">
  <a href="index.php" class="w3-bar-item w3-button w3-mobile ">HOME</a>
   <a href="#" class="w3-bar-item w3-button w3-mobile w3-right" data-toggle="modal" data-target="#myModal">LOGIN</a>
  <a href="#" class="w3-bar-item w3-button w3-mobile w3-right">LOCATE BANKS </a>
  <a href="search.php" class="w3-bar-item w3-button w3-mobile w3-right">SEARCH BLOOD</a>
 
</div><br/></br></br>


<div class="row">
  <div class="col-lg-6 text-center" >
    <a href="search.php"><h2 class="text-primary">Search for Blood Banks</h2></a>
  </div>
  <div class="col-lg-6 text-center">
    <a href="searchdonor.php"><h2 class="text-primary bg-info">Search for Donors</h2></a>
  </div>
</div>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rajhack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM user";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    echo '<table style="width:100%" class="w3-table-all w3-hoverable">
        <tr>
        <th>Blood Group</th>
        <th>Name</th>
        <th>Contact</th>
        <th>E-mail</th>
        <th>Address</th>
        </tr>';
    while($row = $result->fetch_assoc()) {
        echo  "<tr> <td>" . $row["bloodgroup"]. "</td> " ."<td>" . $row["name"]. "</td> " .
        "<td>" . $row["contact"]. "</td> " ."<td>" . $row["address"]. "</td> " ."<td>".  $row["address"]. "</td></tr>";
    }

} else {
    echo "0 results";
}
$conn->close();
?>




</body>

</html>