<?php
$sql= "INSERT INTO user(username,name,email,address,bloodgroup,password,contact) VALUES ('$user','$name','$email','$address','$bg','$password','$contact')";
            
if($conn->query($sql)===TRUE)
{
    echo"Thankyou! ". $name.".<br>You are Registered Successfuly.";
    include "show.php";
}
else
{
    echo("Sorry... Couldn't Register.<br>". $conn->error);
    session_unset(); 

    // destroy the session 
    session_destroy(); 

    header("refresh:2;url=index.php");
}
?>

 