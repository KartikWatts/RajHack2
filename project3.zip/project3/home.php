<?php
// Start the session
session_start();
if(@ $_SESSION['path']!=1)
require 'logconnect.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Home</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="style/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="style/w3.css">
        <link rel="stylesheet" type="text/css" href="style/mystyle.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-default w3-orange">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand w3-red" href="#">Project1</a>
                </div>
                <ul class="nav navbar-nav">
                    <!--<li><a href="#">Home</a></li>
                    <li><a href="#">Page 1</a></li>
                    <li><a href="#">Page 2</a></li>
                    <li><a href="#">Page 3</a></li>
                    -->
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="profile.php" class="w3-teal w3-hover-black"><span class="glyphicon glyphicon-user"></span> Profile</a></li>
                    <li><a href="logout.php" class="w3-blue w3-hover-black"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                </ul>
            </div>
        </nav>
    </body>
</html>