<?php
@include "connect.php";

if(! get_magic_quotes_gpc() ) 
{
    $user=addslashes($_POST['user']);
    $name=addslashes($_POST['name']);
    $email=addslashes($_POST['email']);
    $address=addslashes($_POST['address']);
    $password=addslashes($_POST['password']);
    $bg=addslashes($_POST['bg']);
    $contact=addslashes($_POST['contact']);
}
else
{
    $user=$_POST['user'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $password=$_POST['password'];
    $bg=$_POST['bg'];
    $contact=($_POST['contact']);
}

$_SESSION["user"]="$user";
$_SESSION["name"]="$name";
$_SESSION["email"]="$email";
$_SESSION["contact"]="$contact";
$_SESSION["address"]="$address";
$_SESSION["bg"]="$bg";
$_SESSION["password"]="$password";

    $user= $_SESSION["user"];
    $name=$_SESSION["name"];
    $email=$_SESSION["email"];
    $contact=$_SESSION["contact"];
    $address=$_SESSION["address"];
    $bg=$_SESSION["bg"];
    $password=$_SESSION["password"];
?>
