      <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <a class="navbar-brand" href="#page-top">Bank of Life</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="#about">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="locate.html">Locate Banks</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="search.php">Search Blood</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#myModal" href="#">Login</a>
          </li>
        </ul>
      </div>
    </nav>

    <!--for user login -->
<div class="modal fade" id="myModal" role="dialog">
	<div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Log-in for User</h4>
			   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
               
            </div>
            <div class="modal-body ">
                <form action="indexlog.php" method="POST">
                <div class="form-group">
    		        <label for="exampleInputEadd">User ID</label>
    		        <input class="form-control" name="user" id="exampleInputEadd" placeholder="Enter User Name" type="text">
  		        </div>
		        <div class="form-group">
		  	        <label for="exampleInputPassword1">Password</label>
			        <input class="form-control" name="password" id="exampleInputPassword1" placeholder="Password" type="password">
                </div>
                <input type="submit" class="btn btn-primary btn-lg">
                </form>
		        <div>
				
                    <p class="text-right"><a href="#">Forgot password?</a></p>  
				</div>
				<div>
                     <p>New User<a href="reg.html"> REGISTER</a></p>
                </div>	
			
                <div>
				        <p><a href="logowner.html">BLOOD BANK OWNER Login</a>
                        </p>
			    </div>
			
			</div>
			
		
            <div class="modal-footer">
             
			  <a href="#" data-dismiss="modal" class="btn">Close</a>
				
            </div>
        </div>
    </div>
</div>





