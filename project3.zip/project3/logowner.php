<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>The Bank of Life</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--W3.CSS -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/creative.min.css" rel="stylesheet">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


  </head>

  <body id="page-top">
  
  <?php
   if(@$_SESSION['log'] == 1){
      include "headerlogin.php";
    }
    else{
      include "header.php";
    }
    ?> 
<div class="container">
	<div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Log-in for Blood Bank Owner</h4>
			   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times</button>
               
            </div>
            <div class="modal-body ">
                <form action="ownerlog.php" method="POST">
                <div class="form-group">
    		        <label for="exampleInputEadd">Blood Bank ID</label>
    		        <input class="form-control" name="user" id="exampleInputEadd" placeholder="Enter Blood Bank ID" type="text">
  		        </div>
		        <div class="form-group">
		  	        <label for="exampleInputPassword1">Password</label>
			        <input class="form-control" name="password" id="exampleInputPassword1" placeholder="Password" type="password">
                </div>
                <input type="submit" class="btn btn-primary btn-lg">
                </form>
		        <div>
				
                    <p class="text-right"><a href="#">Forgot password?</a></p>  
				</div>
				<div>
                     <p>Not Registered?<a href="regowner.html"> REGISTER HERE</a></p>
                </div>	
			
                <div>
				        <p class="text-left">Searching for Blood <a class="nav-link" data-toggle="modal" data-target="#myModal" href="#">Login</a>
           </a></p>
			    </div>
			
			</div>
			
		
            <div class="modal-footer">
             
			  <a href="#" data-dismiss="modal" class="btn">Close</a>
				
            </div>
        </div>
    </div>
</div>
</body>
</html>