<?php
// Start the session
session_start();
if(@ $_SESSION['path']!=1)
require 'logconnect.php';
?>