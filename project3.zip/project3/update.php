<?php
session_start();
include "define.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Update Form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    </head>
    <body>
      <div class="w3-third">

        <div class="w3-container w3-panel w3-red">
            Update Information
        </div>
        <form class="w3-container" action="updated.php" method="POST" enctype="multipart/form-data">
               
               <label class="w3-container w3-text-purple">UserName  :
                   <input class="w3-input" type="text" name="user" value="<?php echo $user; ?>">
               </label>
               <label class="w3-container w3-text-purple">Name  :
                   <input class="w3-input" type="text" name="name" value="<?php echo $name; ?>">
               </label>
               <label class="w3-container w3-text-purple">E-mail  :
                   <input class="w3-input" type="email" name="email" value="<?php echo $email; ?>">
               </label>
               <label class="w3-container w3-text-purple">Address  :
                   <input class="w3-input" type="text" name="address" value="<?php echo $address; ?>">
               </label>
               <label class="w3-container w3-text-purple">Contact No.  :
                   <input class="w3-input" type="text" name="contact" value="<?php echo $contact; ?>">
               </label>
               <label class="w3-container w3-text-purple">Blood Group  :
                   <input class="w3-input" type="text" name="bg" value="<?php echo $bg; ?>">
               </label>
               <label class="w3-container w3-text-purple">Password :
                   <input class="w3-input" type="password" name="pass" value="<?php echo $password; ?>">
               </label>
               <div class="w3-display-container">
               </div>
            <br>
            <input class="w3-btn w3-orange w3-round" type="submit" name="" value="Update">
        </form>
     </div>
     <br>
     <br>
    </body>
</html>