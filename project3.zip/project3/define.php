<?php    
    $user= $_SESSION["user"];
    $name=$_SESSION["name"];
    $email=$_SESSION["email"];
    $contact=$_SESSION["contact"];
    $address=$_SESSION["address"];
    $bg=$_SESSION["bg"];
    $password=$_SESSION["password"];
?>