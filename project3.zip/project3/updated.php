<?php
include "connect.php";
include "define.php";

if(! get_magic_quotes_gpc() ) 
{
    $user=addslashes($_POST['user']);
    $name=addslashes($_POST['name']);
    $email=addslashes($_POST['email']);
    $address=addslashes($_POST['address']);
    $pass=addslashes($_POST['password']);
    $bg=addslashes($_POST['bg']);
    $contact=addslashes($_POST['contact']);
}
else
{
    $user=$_POST['user'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $pass=$_POST['password'];
    $bg=$_POST['bg'];
    $contact=($_POST['contact']);
}


$sql = "UPDATE user SET name='$name', email='$email', contact='$contact', bloodgroup='$bg', address='$address' WHERE user='$user'";

if($conn->query($sql)===TRUE)
{
    echo $fname.".<br>Your Information updated Successfuly.";
}
else
{
    echo("Sorry... Couldn't Register.<br>". $conn->error);
}

$_SESSION["user"]="$user";
$_SESSION["name"]="$name";
$_SESSION["email"]="$email";
$_SESSION["contact"]="$contact";
$_SESSION["address"]="$address";
$_SESSION["bg"]="$bg";
$_SESSION["password"]="$password";

header("url=index.php");

?>