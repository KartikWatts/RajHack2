<?php
@session_start();

 $user= $_SESSION["user"];
    $name=$_SESSION["name"];
    $email=$_SESSION["email"];
    $contact=$_SESSION["contact"];
    $address=$_SESSION["address"];
    $bg=$_SESSION["bg"];
    $pass=$_SESSION["password"];

?>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    </head>
    <body>
        <a href="index.html"><h2> Home Page </h2></a>
        
        <table class="w3-table-all w3-hoverable w3-responsive">
            <div class="w3-container w3-xlarge w3-hover-blue w3-panel w3-yellow">
            Your Information is:
            </div> 
            <tr class="w3-hover-red"><td>User Name:</td> <td><?php echo $user; ?></td></tr>
            <tr class="w3-hover-orange"><td>Name:</td><td><?php echo $name; ?></td></tr>
            <tr class="w3-hover-yellow"><td> E-mail:</td><td><?php echo $email; ?></td></tr>
            <tr class="w3-hover-green"><td>Contact:</td><td><?php echo $contact; ?></td></tr>
            <tr class="w3-hover-blue"><td>Address:</td><td><?php echo $address; ?></td></tr>            
            <tr class="w3-hover-blue"><td>Blood-Group:</td><td><?php echo $bg; ?></td></tr>            

            <td>
                <div class="w3-display-container">
               </div>
            </td>
            </tr>
            <br>
        </table>
        <a class="w3-btn w3-blue w3-text-shadow" href="update.php"><b>Update or Change Information</b></a>
        <br><br><br>
    </body>
</html>